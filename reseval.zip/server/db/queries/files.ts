import { Query } from '..';

const all = () => Query('SELECT * FROM files');

export default { all }
